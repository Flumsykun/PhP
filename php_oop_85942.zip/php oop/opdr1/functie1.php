<?php
// function BerekenOppervlakte($straal){
//     $oppervlakte = pi() * $straal * $straal;
//     echo "De oppervlakte van een cirkel met straal $straal is $oppervlakte";
    
// }
// BerekenOppervlakte(140,7);
?>